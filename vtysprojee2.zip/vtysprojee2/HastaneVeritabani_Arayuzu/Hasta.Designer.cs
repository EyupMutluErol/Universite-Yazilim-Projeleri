﻿
namespace HastaneVeritabani_Arayuzu
{
    partial class Hasta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txKilo = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txBoy = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txTel = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txMail = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txKangrubu = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txSigorta = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txCinsiyet = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txTc = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.bhGuncelle = new System.Windows.Forms.Button();
            this.txSoyad = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.bhSil = new System.Windows.Forms.Button();
            this.txAd = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.bhEkle = new System.Windows.Forms.Button();
            this.txHastaid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bhListele = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txKilo
            // 
            this.txKilo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txKilo.Location = new System.Drawing.Point(720, 620);
            this.txKilo.Margin = new System.Windows.Forms.Padding(4);
            this.txKilo.Name = "txKilo";
            this.txKilo.Size = new System.Drawing.Size(132, 27);
            this.txKilo.TabIndex = 61;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(670, 620);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 25);
            this.label12.TabIndex = 60;
            this.label12.Text = "Kilo";
            // 
            // txBoy
            // 
            this.txBoy.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txBoy.Location = new System.Drawing.Point(720, 564);
            this.txBoy.Margin = new System.Windows.Forms.Padding(4);
            this.txBoy.Name = "txBoy";
            this.txBoy.Size = new System.Drawing.Size(132, 27);
            this.txBoy.TabIndex = 59;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(668, 564);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 25);
            this.label11.TabIndex = 58;
            this.label11.Text = "Boy";
            // 
            // txTel
            // 
            this.txTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txTel.Location = new System.Drawing.Point(720, 506);
            this.txTel.Margin = new System.Windows.Forms.Padding(4);
            this.txTel.Name = "txTel";
            this.txTel.Size = new System.Drawing.Size(132, 27);
            this.txTel.TabIndex = 57;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(672, 506);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 25);
            this.label10.TabIndex = 56;
            this.label10.Text = "Tel";
            // 
            // txMail
            // 
            this.txMail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txMail.Location = new System.Drawing.Point(460, 676);
            this.txMail.Margin = new System.Windows.Forms.Padding(4);
            this.txMail.Name = "txMail";
            this.txMail.Size = new System.Drawing.Size(132, 27);
            this.txMail.TabIndex = 55;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(343, 678);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 25);
            this.label9.TabIndex = 54;
            this.label9.Text = "Mail";
            // 
            // txKangrubu
            // 
            this.txKangrubu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txKangrubu.Location = new System.Drawing.Point(460, 620);
            this.txKangrubu.Margin = new System.Windows.Forms.Padding(4);
            this.txKangrubu.Name = "txKangrubu";
            this.txKangrubu.Size = new System.Drawing.Size(132, 27);
            this.txKangrubu.TabIndex = 51;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(343, 622);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 25);
            this.label7.TabIndex = 50;
            this.label7.Text = "Kan grubu";
            // 
            // txSigorta
            // 
            this.txSigorta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txSigorta.Location = new System.Drawing.Point(460, 565);
            this.txSigorta.Margin = new System.Windows.Forms.Padding(4);
            this.txSigorta.Name = "txSigorta";
            this.txSigorta.Size = new System.Drawing.Size(132, 27);
            this.txSigorta.TabIndex = 49;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(343, 566);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 25);
            this.label6.TabIndex = 48;
            this.label6.Text = "Sigorta";
            // 
            // txCinsiyet
            // 
            this.txCinsiyet.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txCinsiyet.Location = new System.Drawing.Point(460, 509);
            this.txCinsiyet.Margin = new System.Windows.Forms.Padding(4);
            this.txCinsiyet.Name = "txCinsiyet";
            this.txCinsiyet.Size = new System.Drawing.Size(132, 27);
            this.txCinsiyet.TabIndex = 47;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(343, 512);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 25);
            this.label5.TabIndex = 46;
            this.label5.Text = "Cinsiyet";
            // 
            // txTc
            // 
            this.txTc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txTc.Location = new System.Drawing.Point(110, 676);
            this.txTc.Margin = new System.Windows.Forms.Padding(4);
            this.txTc.Name = "txTc";
            this.txTc.Size = new System.Drawing.Size(132, 27);
            this.txTc.TabIndex = 45;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(16, 678);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 25);
            this.label4.TabIndex = 44;
            this.label4.Text = "TC No";
            // 
            // bhGuncelle
            // 
            this.bhGuncelle.BackColor = System.Drawing.Color.MediumOrchid;
            this.bhGuncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bhGuncelle.Location = new System.Drawing.Point(1149, 495);
            this.bhGuncelle.Margin = new System.Windows.Forms.Padding(4);
            this.bhGuncelle.Name = "bhGuncelle";
            this.bhGuncelle.Size = new System.Drawing.Size(119, 56);
            this.bhGuncelle.TabIndex = 43;
            this.bhGuncelle.Text = "Güncelle";
            this.bhGuncelle.UseVisualStyleBackColor = false;
            this.bhGuncelle.Click += new System.EventHandler(this.bhGuncelle_Click_1);
            // 
            // txSoyad
            // 
            this.txSoyad.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txSoyad.Location = new System.Drawing.Point(110, 620);
            this.txSoyad.Margin = new System.Windows.Forms.Padding(4);
            this.txSoyad.Name = "txSoyad";
            this.txSoyad.Size = new System.Drawing.Size(132, 27);
            this.txSoyad.TabIndex = 42;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(16, 622);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 25);
            this.label3.TabIndex = 41;
            this.label3.Text = "Soyad";
            // 
            // bhSil
            // 
            this.bhSil.BackColor = System.Drawing.Color.Salmon;
            this.bhSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bhSil.Location = new System.Drawing.Point(1025, 495);
            this.bhSil.Margin = new System.Windows.Forms.Padding(4);
            this.bhSil.Name = "bhSil";
            this.bhSil.Size = new System.Drawing.Size(119, 56);
            this.bhSil.TabIndex = 40;
            this.bhSil.Text = "Sil";
            this.bhSil.UseVisualStyleBackColor = false;
            this.bhSil.Click += new System.EventHandler(this.bhSil_Click_1);
            // 
            // txAd
            // 
            this.txAd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txAd.Location = new System.Drawing.Point(110, 567);
            this.txAd.Margin = new System.Windows.Forms.Padding(4);
            this.txAd.Name = "txAd";
            this.txAd.Size = new System.Drawing.Size(132, 27);
            this.txAd.TabIndex = 39;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(16, 567);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 25);
            this.label2.TabIndex = 38;
            this.label2.Text = "Ad";
            // 
            // bhEkle
            // 
            this.bhEkle.BackColor = System.Drawing.Color.MediumTurquoise;
            this.bhEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bhEkle.Location = new System.Drawing.Point(898, 495);
            this.bhEkle.Margin = new System.Windows.Forms.Padding(4);
            this.bhEkle.Name = "bhEkle";
            this.bhEkle.Size = new System.Drawing.Size(119, 56);
            this.bhEkle.TabIndex = 37;
            this.bhEkle.Text = "Ekle";
            this.bhEkle.UseVisualStyleBackColor = false;
            this.bhEkle.Click += new System.EventHandler(this.bhEkle_Click_1);
            // 
            // txHastaid
            // 
            this.txHastaid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txHastaid.Location = new System.Drawing.Point(110, 509);
            this.txHastaid.Margin = new System.Windows.Forms.Padding(4);
            this.txHastaid.Name = "txHastaid";
            this.txHastaid.Size = new System.Drawing.Size(132, 27);
            this.txHastaid.TabIndex = 36;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(16, 508);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 25);
            this.label1.TabIndex = 35;
            this.label1.Text = "Hasta ID";
            // 
            // bhListele
            // 
            this.bhListele.BackColor = System.Drawing.Color.Chocolate;
            this.bhListele.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bhListele.Location = new System.Drawing.Point(898, 582);
            this.bhListele.Margin = new System.Windows.Forms.Padding(4);
            this.bhListele.Name = "bhListele";
            this.bhListele.Size = new System.Drawing.Size(370, 64);
            this.bhListele.TabIndex = 34;
            this.bhListele.Text = "Tümünü Listele";
            this.bhListele.UseVisualStyleBackColor = false;
            this.bhListele.Click += new System.EventHandler(this.bhListele_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(13, 85);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(1240, 384);
            this.dataGridView1.TabIndex = 33;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Coral;
            this.label8.Font = new System.Drawing.Font("Bahnschrift Condensed", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label8.Location = new System.Drawing.Point(492, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(269, 45);
            this.label8.TabIndex = 62;
            this.label8.Text = "HASTA KAYIT MODÜLÜ";
            // 
            // Hasta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Coral;
            this.ClientSize = new System.Drawing.Size(1276, 740);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txKilo);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txBoy);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txTel);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txMail);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txKangrubu);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txSigorta);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txCinsiyet);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txTc);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.bhGuncelle);
            this.Controls.Add(this.txSoyad);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.bhSil);
            this.Controls.Add(this.txAd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.bhEkle);
            this.Controls.Add(this.txHastaid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bhListele);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Hasta";
            this.Text = "Hasta";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txKilo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txBoy;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txTel;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txMail;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txKangrubu;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txSigorta;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txCinsiyet;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txTc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button bhGuncelle;
        private System.Windows.Forms.TextBox txSoyad;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bhSil;
        private System.Windows.Forms.TextBox txAd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bhEkle;
        private System.Windows.Forms.TextBox txHastaid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bhListele;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label8;
    }
}